# Created by Daniël Jrifat

totalEcars <<- length(which(rdwDataF$BRANDSTOFCODE == "E"))

Sfuelcount<- subset(fuelcount)

Sfuelcount$Pct <- Sfuelcount$freq / sum(Sfuelcount$freq)*100
Sfuelcount

rdw1heatMapVar <- c(
  # vars to select inputfile
  "bestand 1",
  "bestand 2",
  "bestand 3",
  "bestand 4",
  "bestand 5",
  "bestand 6",
  "bestand 7"
)
